package pl.aibooster.pro

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 15, 25)
        window.navigationBarColor = Color.rgb(12, 15, 25)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(20))
            setBackgroundColor(Color.rgb(12, 15, 25))
        }

        val title = TextView(this).apply {
            text = "AI BOOSTER PRO"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "ROBLOX EDITION • REALME NOTE 50"
            textSize = 13f
            setTextColor(Color.rgb(100, 210, 255))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(22))
        }
        root.addView(subtitle, matchWrap())

        val info = TextView(this).apply {
            text = "Profil gry\n\n• Roblox: jakość grafiki 1–2\n• Ekran: 90 Hz, jeśli dostępne\n• Oszczędzanie baterii: wyłączone podczas gry\n• Zamknij nieużywane aplikacje\n• Rób przerwy, jeśli telefon się nagrzewa"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.rgb(26, 32, 48))
        }
        root.addView(info, matchWrap())

        val button = Button(this).apply {
            text = "SPRAWDŹ USTAWIENIA"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Szybka kontrola")
                    .setMessage("Ustaw w Roblox: Settings → Graphics Mode → Manual, a Graphics Quality na 1–2. Ta aplikacja nie zmienia ustawień Roblox automatycznie.")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(18) }
        root.addView(button, params)

        val note = TextView(this).apply {
            text = "Uwaga: aplikacja nie podkręca procesora, nie odblokowuje FPS i nie dodaje DLSS. Android nie pozwala zwykłej aplikacji bezpiecznie sterować tymi funkcjami w Roblox."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(note, matchWrap())

        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
