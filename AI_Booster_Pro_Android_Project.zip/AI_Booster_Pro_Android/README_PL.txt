AI BOOSTER PRO — projekt Android

Ważne:
To jest projekt źródłowy aplikacji, a nie gotowy plik APK. W tym środowisku nie ma Android SDK/Gradle potrzebnych do zbudowania i podpisania APK.

Co robi aplikacja:
- pokazuje bezpieczny profil ustawień Roblox dla Realme Note 50,
- wyjaśnia, gdzie ustawić niską jakość grafiki,
- nie wymaga specjalnych uprawnień.

Czego nie robi:
- nie zwiększa fizycznie mocy procesora ani GPU,
- nie gwarantuje większej liczby FPS,
- nie ingeruje w Roblox i nie dodaje DLSS.

Jak zbudować APK:
1. Zainstaluj Android Studio na komputerze.
2. Otwórz w nim folder AI_Booster_Pro_Android.
3. Poczekaj na synchronizację Gradle.
4. Wybierz Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK znajdziesz w app/build/outputs/apk/debug/app-debug.apk.

Minimalny SDK: Android 6.0 (API 23). Projekt używa standardowych komponentów Androida.
